

class CellParser:
    def __init__(self) -> None:
        pass

    def parse(self, file: str) -> list[list[int]]:
        return []